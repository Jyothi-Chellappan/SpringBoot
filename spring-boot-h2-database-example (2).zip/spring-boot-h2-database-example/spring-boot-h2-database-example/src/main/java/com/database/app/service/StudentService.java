package com.database.app.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.database.app.model.Student;
import com.database.app.repository.StudentRepository;
//defining the business logic
@Service
public class StudentService {
@Autowired
StudentRepository studentRepository;

public List<Student> getAllStudent() 
{
	//findAll() is predefined method in CRUD Repository
List<Student> students = new ArrayList<Student>();
studentRepository.findAll().forEach(student -> students.add(student));//java 8 lambda expressions
return students;
}

//findById() is predefined method in CRUD Repository
public Student getStudentById(int id) 
{
return studentRepository.findById(id).get();
}
//save() is predefined method in CRUD Repository

public void saveOrUpdate(Student student) 
{
studentRepository.save(student);
}
//save() is predefined method in CRUD Repository
public void delete(int id) 
{
studentRepository.deleteById(id);
}
}